// SPDX-License-Identifier: MIT
pragma solidity 0.8.19;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/Strings.sol";
import "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";

contract BlockstarDomains is ERC721, ERC721URIStorage, Ownable {
    using EnumerableSet for EnumerableSet.Bytes32Set;

    // --- State Variables ---
    uint256 public registrationFee;
    uint256 public renewalFee;
    uint256 public constant RENEWAL_DURATION = 365 days;

    mapping(string => uint256) public nameToTokenId;
    mapping(uint256 => string) private tokenIdToName;
    mapping(uint256 => uint256) public expirations;
    mapping(address => string) public primaryNames;
    mapping(uint256 => mapping(string => string)) private records;
    mapping(uint256 => string[]) private recordKeys;

    // --- Subdomain mappings ---
    mapping(uint256 => EnumerableSet.Bytes32Set) private subdomainHashes; // tokenId => set of subdomain hashes
    mapping(bytes32 => uint256) private subdomainHashToParentId; // subdomain hash => parent tokenId
    mapping(bytes32 => mapping(string => string)) private subdomainRecords; // subdomain hash => key => value
    mapping(bytes32 => string[]) private subdomainRecordKeys; // subdomain hash => array of keys
    mapping(bytes32 => string) private hashToLabel;

    uint256 private _nextTokenId;
    mapping(bytes32 => address) public subdomainDelegates;

    // --- Subdomain struct for return data ---
    struct SubdomainInfo {
        string name;
        string fullName;
        string[] keys;
        string[] values;
    }

    // --- Events ---
    event DomainRegistered(uint256 indexed tokenId, string name, address indexed owner, uint256 expires);
    event DomainRenewed(uint256 indexed tokenId, string name, uint256 expires);
    event RecordSet(uint256 indexed tokenId, string name, string key, string value);
    event PrimaryNameSet(address indexed owner, string name);
    event PrimaryNameCleared(address indexed owner, string name);
    event SubdomainDelegated(uint256 indexed parentTokenId, string subdomain, address indexed delegate);

    // --- Subdomain events ---
    event SubdomainCreated(uint256 indexed parentTokenId, string subdomain, string fullName);
    event SubdomainRemoved(uint256 indexed parentTokenId, string subdomain, string fullName);
    event SubdomainRecordSet(uint256 indexed parentTokenId, string subdomain, string key, string value);

    // --- Constructor ---
    constructor() ERC721("Blockstar Domains", "BSTAR") Ownable() {
        registrationFee = 10e18;
        renewalFee = 20e18;
    }

    // --- Helper Functions ---
    function _getSubdomainHash(string memory subdomain, uint256 parentTokenId) public pure returns (bytes32) {
        return keccak256(abi.encodePacked(subdomain, parentTokenId));
    }

    function _getFullSubdomainName(string memory subdomain, string memory parentName) public pure returns (string memory) {
        return string(abi.encodePacked(subdomain, ".", parentName));
    }

    // --- Core Functions ---

    function isAvailable(string memory name) public view returns (bool) {
        string[] memory parts = _split(name, ".");
        string memory rootName = "";
        if (parts.length == 1) {
            rootName = parts[0];
        } else {
            rootName = _join(parts, 1);
        }

        uint256 tokenId = nameToTokenId[name];
        if (tokenId == 0) {
            return true;
        }

        return expirations[tokenId] < block.timestamp;
    }

    function register(string calldata name) public payable {
        // Split the name into parts (e.g., "demo.test" → ["demo", "test"])
        string[] memory parts = _split(name, ".");

        if (parts.length == 1) {
            // --------------------
            // Register Root Domain
            // --------------------
            string memory rootName = parts[0];
            require(isAvailable(rootName), "Domain is not available");
            require(msg.value >= registrationFee, "Insufficient fee");

            uint256 tokenId = nameToTokenId[rootName];

            if (tokenId == 0) {
                // New registration
                _nextTokenId++;
                tokenId = _nextTokenId;
                nameToTokenId[rootName] = tokenId;
                tokenIdToName[tokenId] = rootName;
                _safeMint(msg.sender, tokenId);
            } else {
                // Re-registering expired
                _transfer(ownerOf(tokenId), msg.sender, tokenId);
            }

            uint256 expirationTime = block.timestamp + RENEWAL_DURATION;
            expirations[tokenId] = expirationTime;

            if (bytes(primaryNames[msg.sender]).length == 0) {
                _setPrimaryName(msg.sender, rootName);
            }

            emit DomainRegistered(tokenId, rootName, msg.sender, expirationTime);
        } else {
            // --------------------
            // Create Subdomain
            // --------------------
            string memory subLabel = parts[0];
            string memory parentName = _join(parts, 1); // join from index 1 → "chatgpt"

            uint256 parentTokenId = nameToTokenId[parentName];
            require(parentTokenId != 0, "Parent domain does not exist");
            require(ownerOf(parentTokenId) == msg.sender, "Not owner of parent");
            require(expirations[parentTokenId] >= block.timestamp, "Parent expired");
            require(bytes(subLabel).length > 0, "Subdomain empty");

            bytes32 subHash = _getSubdomainHash(subLabel, parentTokenId);
            require(subdomainHashToParentId[subHash] == 0, "Subdomain exists");

            // Add subdomain
            subdomainHashes[parentTokenId].add(subHash);
            subdomainHashToParentId[subHash] = parentTokenId;
            hashToLabel[subHash] = subLabel;
            subdomainDelegates[subHash] = msg.sender;

            string memory fullName = _getFullSubdomainName(subLabel, parentName);
            emit SubdomainCreated(parentTokenId, subLabel, fullName);
        }
    }

    function renew(string calldata name) public payable {
        uint256 tokenId = nameToTokenId[name];
        require(tokenId != 0, "Domain does not exist");
        require(ownerOf(tokenId) == msg.sender, "You are not the owner");
        require(msg.value >= renewalFee, "Insufficient fee for renewal");

        uint256 newExpiration = expirations[tokenId] + RENEWAL_DURATION;
        expirations[tokenId] = newExpiration;

        emit DomainRenewed(tokenId, name, newExpiration);
    }

    function setRecord(string calldata name, string calldata key, string calldata value) public {
        uint256 tokenId = nameToTokenId[name];
        require(ownerOf(tokenId) == msg.sender, "You are not the owner");

        // If key is new, push it to recordKeys
        if (bytes(records[tokenId][key]).length == 0 && bytes(value).length > 0) {
            recordKeys[tokenId].push(key);
        }

        records[tokenId][key] = value;

        emit RecordSet(tokenId, name, key, value);
    }

    function getAllRecords(string calldata name) public view returns (string[] memory keys, string[] memory values) {
        uint256 tokenId = nameToTokenId[name];
        require(tokenId != 0, "Domain does not exist");

        string[] memory storedKeys = recordKeys[tokenId];
        string[] memory storedValues = new string[](storedKeys.length);

        for (uint256 i = 0; i < storedKeys.length; i++) {
            storedValues[i] = records[tokenId][storedKeys[i]];
        }

        return (storedKeys, storedValues);
    }

    function setPrimaryName(string calldata name) public {
        uint256 tokenId = nameToTokenId[name];
        require(ownerOf(tokenId) == msg.sender, "You are not the owner");
        primaryNames[msg.sender] = name;
        emit PrimaryNameSet(msg.sender, name);
    }

    function removeSubdomain(string calldata parentName, string calldata subdomain) public {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");
        require(ownerOf(parentTokenId) == msg.sender, "You are not the owner of parent domain");

        bytes32 subdomainHash = _getSubdomainHash(subdomain, parentTokenId);
        require(subdomainHashToParentId[subdomainHash] == parentTokenId, "Subdomain does not exist");

        // Remove from parent's set
        subdomainHashes[parentTokenId].remove(subdomainHash);
        delete subdomainHashToParentId[subdomainHash];

        // Clear all records for this subdomain
        string[] memory keys = subdomainRecordKeys[subdomainHash];
        for (uint256 i = 0; i < keys.length; i++) {
            delete subdomainRecords[subdomainHash][keys[i]];
        }
        delete subdomainRecordKeys[subdomainHash];

        string memory fullName = _getFullSubdomainName(subdomain, parentName);
        emit SubdomainRemoved(parentTokenId, subdomain, fullName);
    }

    function setSubdomainRecord(string calldata parentName, string calldata subdomain, string calldata key, string calldata value) public {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");
        require(expirations[parentTokenId] >= block.timestamp, "Parent domain is expired");

        bytes32 subdomainHash = _getSubdomainHash(subdomain, parentTokenId);
        require(subdomainHashToParentId[subdomainHash] == parentTokenId, "Subdomain does not exist");

        // [MODIFIED] CRITICAL CHECK: Only the delegated address can set records.
        address delegate = subdomainDelegates[subdomainHash];
        require(delegate == msg.sender, "You are not the delegate for this subdomain.");

        if (bytes(subdomainRecords[subdomainHash][key]).length == 0 && bytes(value).length > 0) {
            subdomainRecordKeys[subdomainHash].push(key);
        }

        subdomainRecords[subdomainHash][key] = value;
        emit SubdomainRecordSet(parentTokenId, subdomain, key, value);
    }

    function setSubdomainDelegate(string calldata parentName, string calldata subdomain, address newDelegate) public {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");
        // [CRITICAL CHECK] Only the current owner of the parent NFT can change the delegate.
        require(ownerOf(parentTokenId) == msg.sender, "You are not the owner of the parent domain.");

        bytes32 subdomainHash = _getSubdomainHash(subdomain, parentTokenId);
        require(subdomainHashToParentId[subdomainHash] == parentTokenId, "Subdomain does not exist");
        require(newDelegate != address(0), "Delegate cannot be the zero address.");

        subdomainDelegates[subdomainHash] = newDelegate;
        emit SubdomainDelegated(parentTokenId, subdomain, newDelegate);
    }

    function getSubdomainRecord(string calldata parentName, string calldata subdomain, string calldata key) public view returns (string memory) {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");

        bytes32 subdomainHash = _getSubdomainHash(subdomain, parentTokenId);
        require(subdomainHashToParentId[subdomainHash] == parentTokenId, "Subdomain does not exist");

        return subdomainRecords[subdomainHash][key];
    }

    function getAllSubdomainRecords(string calldata parentName, string calldata subdomain) public view returns (string[] memory keys, string[] memory values) {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");

        bytes32 subdomainHash = _getSubdomainHash(subdomain, parentTokenId);
        require(subdomainHashToParentId[subdomainHash] == parentTokenId, "Subdomain does not exist");

        string[] memory storedKeys = subdomainRecordKeys[subdomainHash];
        string[] memory storedValues = new string[](storedKeys.length);

        for (uint256 i = 0; i < storedKeys.length; i++) {
            storedValues[i] = subdomainRecords[subdomainHash][storedKeys[i]];
        }

        return (storedKeys, storedValues);
    }

    function getAllSubdomains(string calldata parentName) public view returns (SubdomainInfo[] memory) {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");

        uint256 subdomainCount = subdomainHashes[parentTokenId].length();
        SubdomainInfo[] memory subdomains = new SubdomainInfo[](subdomainCount);

        for (uint256 i = 0; i < subdomainCount; i++) {
            bytes32 subdomainHash = subdomainHashes[parentTokenId].at(i);
            string memory label = hashToLabel[subdomainHash];
            string memory fullName = string(abi.encodePacked(label, ".", parentName));

            // Collect records
            string[] memory keys = subdomainRecordKeys[subdomainHash];
            string[] memory values = new string[](keys.length);
            for (uint256 j = 0; j < keys.length; j++) {
                values[j] = subdomainRecords[subdomainHash][keys[j]];
            }

            // Assign to struct
            subdomains[i] = SubdomainInfo({name: label, fullName: fullName, keys: keys, values: values});
        }

        return subdomains;
    }

    function getSubdomainCount(string calldata parentName) public view returns (uint256) {
        uint256 parentTokenId = nameToTokenId[parentName];
        require(parentTokenId != 0, "Parent domain does not exist");
        return subdomainHashes[parentTokenId].length();
    }

    function subdomainExists(string calldata parentName, string calldata subdomain) public view returns (bool) {
        uint256 parentTokenId = nameToTokenId[parentName];
        if (parentTokenId == 0) return false;

        bytes32 subdomainHash = _getSubdomainHash(subdomain, parentTokenId);
        return subdomainHashToParentId[subdomainHash] == parentTokenId;
    }

    // === UNIFIED RECORD FUNCTION ===
    // If subdomain is empty (""), returns main domain records
    // If subdomain is provided, returns subdomain records
    function getUnifiedRecords(string calldata domainName, string calldata subdomain) public view returns (string[] memory keys, string[] memory values) {
        uint256 tokenId = nameToTokenId[domainName];
        require(tokenId != 0, "Domain does not exist");

        // If subdomain is empty, return main domain records
        if (bytes(subdomain).length == 0) {
            string[] memory domainKeys = recordKeys[tokenId];
            string[] memory domainValues = new string[](domainKeys.length);

            for (uint256 i = 0; i < domainKeys.length; i++) {
                domainValues[i] = records[tokenId][domainKeys[i]];
            }

            return (domainKeys, domainValues);
        }

        // Otherwise, return subdomain records
        bytes32 subdomainHash = _getSubdomainHash(subdomain, tokenId);
        require(subdomainHashToParentId[subdomainHash] == tokenId, "Subdomain does not exist");

        string[] memory subKeys = subdomainRecordKeys[subdomainHash];
        string[] memory subValues = new string[](subKeys.length);

        for (uint256 i = 0; i < subKeys.length; i++) {
            subValues[i] = subdomainRecords[subdomainHash][subKeys[i]];
        }

        return (subKeys, subValues);
    }

    // --- Helper function to convert bytes32 to hex string ---
    function _toHexString(bytes32 value) internal pure returns (string memory) {
        bytes memory buffer = new bytes(64);
        for (uint256 i = 0; i < 32; i++) {
            buffer[i * 2] = _toHexChar(uint8(value[i]) / 16);
            buffer[1 + i * 2] = _toHexChar(uint8(value[i]) % 16);
        }
        return string(buffer);
    }

    function _toHexChar(uint8 value) internal pure returns (bytes1) {
        if (value < 10) {
            return bytes1(uint8(48 + value));
        } else {
            return bytes1(uint8(87 + value));
        }
    }

    // --- View/Getter Functions ---
    function resolve(string calldata name, string calldata key) public view returns (string memory) {
        uint256 tokenId = nameToTokenId[name];
        require(tokenId != 0, "Domain does not exist");
        return records[tokenId][key];
    }

    function getName(uint256 tokenId) public view returns (string memory) {
        return tokenIdToName[tokenId];
    }

    function getNameToTokenId(string calldata name) public view returns (uint256) {
        return nameToTokenId[name];
    }

    function getPrimaryName(address addr) public view returns (string memory) {
        return primaryNames[addr];
    }

    function getExpiration(string calldata name) public view returns (uint256) {
        return expirations[nameToTokenId[name]];
    }

    // --- Admin Functions ---
    function setRegistrationFee(uint256 _newFee) public onlyOwner {
        registrationFee = _newFee;
    }

    function setRenewalFee(uint256 _newFee) public onlyOwner {
        renewalFee = _newFee;
    }

    function withdraw() public onlyOwner {
        (bool success, ) = payable(owner()).call{value: address(this).balance}("");
        require(success, "Withdrawal failed");
    }

    // --- Overrides required by Solidity 0.8+ ---
    function tokenURI(uint256 tokenId) public view override(ERC721, ERC721URIStorage) returns (string memory) {
        return super.tokenURI(tokenId);
    }

    function _burn(uint256 tokenId) internal override(ERC721, ERC721URIStorage) {
        super._burn(tokenId);
    }

    function supportsInterface(bytes4 interfaceId) public view override(ERC721, ERC721URIStorage) returns (bool) {
        return super.supportsInterface(interfaceId);
    }

    function _transfer(address from, address to, uint256 tokenId) internal override {
        string memory currentName = tokenIdToName[tokenId];

        // Clear the primary name of the sender if this was their primary
        if (bytes(primaryNames[from]).length > 0 && keccak256(bytes(primaryNames[from])) == keccak256(bytes(currentName))) {
            delete primaryNames[from];
            emit PrimaryNameCleared(from, currentName);
        }

        super._transfer(from, to, tokenId);

        // Automatically set primary name for the recipient if they don't have one
        if (to != address(0) && bytes(primaryNames[to]).length == 0) {
            _setPrimaryName(to, currentName);
        }

        // Note: Subdomains automatically transfer with the parent domain
        // No additional logic needed as ownership is checked via ownerOf(parentTokenId)
    }

    function _setPrimaryName(address owner, string memory name) internal {
        primaryNames[owner] = name;
        emit PrimaryNameSet(owner, name);
    }

    function _split(string memory str, string memory delim) internal pure returns (string[] memory) {
        bytes memory b = bytes(str);
        bytes memory d = bytes(delim);
        uint count = 1;

        for (uint i = 0; i < b.length; i++) {
            if (b[i] == d[0]) count++;
        }

        string[] memory parts = new string[](count);
        uint k = 0;
        uint last = 0;
        for (uint i = 0; i < b.length; i++) {
            if (b[i] == d[0]) {
                parts[k++] = _substring(str, last, i);
                last = i + 1;
            }
        }
        parts[k] = _substring(str, last, b.length);
        return parts;
    }

    function _substring(string memory str, uint start, uint end) internal pure returns (string memory) {
        bytes memory strBytes = bytes(str);
        bytes memory result = new bytes(end - start);
        for (uint i = start; i < end; i++) {
            result[i - start] = strBytes[i];
        }
        return string(result);
    }

    function _join(string[] memory arr, uint startIndex) internal pure returns (string memory) {
        bytes memory result;
        for (uint i = startIndex; i < arr.length; i++) {
            result = abi.encodePacked(result, arr[i]);
            if (i < arr.length - 1) {
                result = abi.encodePacked(result, ".");
            }
        }
        return string(result);
    }
}
