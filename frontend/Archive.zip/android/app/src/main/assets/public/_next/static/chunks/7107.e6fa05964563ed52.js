"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7107],{67107:function(t,e,r){r.r(e),r.d(e,{PhClock:function(){return c}}),r(31498);var a=r(38157),o=r(48567),i=r(54910),h=r(69709),s=r(78313),l=Object.defineProperty,p=Object.getOwnPropertyDescriptor,n=(t,e,r,a)=>{for(var o,i=a>1?void 0:a?p(e,r):e,h=t.length-1;h>=0;h--)(o=t[h])&&(i=(a?o(e,r,i):o(i))||i);return a&&i&&l(e,r,i),i};let c=class extends o.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return(0,a.dy)`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",(0,a.YP)`<path d="M128,28A100,100,0,1,0,228,128,100.11,100.11,0,0,0,128,28Zm0,192a92,92,0,1,1,92-92A92.1,92.1,0,0,1,128,220Zm60-92a4,4,0,0,1-4,4H128a4,4,0,0,1-4-4V72a4,4,0,0,1,8,0v52h52A4,4,0,0,1,188,128Z"/>`],["light",(0,a.YP)`<path d="M128,26A102,102,0,1,0,230,128,102.12,102.12,0,0,0,128,26Zm0,192a90,90,0,1,1,90-90A90.1,90.1,0,0,1,128,218Zm62-90a6,6,0,0,1-6,6H128a6,6,0,0,1-6-6V72a6,6,0,0,1,12,0v50h50A6,6,0,0,1,190,128Z"/>`],["regular",(0,a.YP)`<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"/>`],["bold",(0,a.YP)`<path d="M128,20A108,108,0,1,0,236,128,108.12,108.12,0,0,0,128,20Zm0,192a84,84,0,1,1,84-84A84.09,84.09,0,0,1,128,212Zm68-84a12,12,0,0,1-12,12H128a12,12,0,0,1-12-12V72a12,12,0,0,1,24,0v44h44A12,12,0,0,1,196,128Z"/>`],["fill",(0,a.YP)`<path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm56,112H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48a8,8,0,0,1,0,16Z"/>`],["duotone",(0,a.YP)`<path d="M224,128a96,96,0,1,1-96-96A96,96,0,0,1,224,128Z" opacity="0.2"/><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"/>`]]),c.styles=(0,s.iv)`
    :host {
      display: contents;
    }
  `,n([(0,h.C)({type:String,reflect:!0})],c.prototype,"size",2),n([(0,h.C)({type:String,reflect:!0})],c.prototype,"weight",2),n([(0,h.C)({type:String,reflect:!0})],c.prototype,"color",2),n([(0,h.C)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=n([(0,i.M)("ph-clock")],c)}}]);